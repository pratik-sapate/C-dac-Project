package com.example.sunbeam.smart_city;

public class Constant_weather {
    public static String SUNNY_TITLE="Sunny";
    public static String SUNNY_NEWS="Please stay safe. wear sun coat while going outside and drink more water";
    public static int SUNNY_ID=R.mipmap.thermometer;
    public static final int MAX_TEMPERATURE=40;




    public static String WINTER_TITLE="Cold";
    public static String WINTER_NEWS="Please stay safe. wear sweater ";
    public static int WINTER_ID=R.mipmap.cold;
    public static final int MIN_TEMPERATURE=20;



    public static String Normal_title="Normal";
    public static String Normal_news="Good whether ";


    public static String GAS_TITLE="POLLUTION";
    public static String GAS_TEXT="you are under polluted area, plz wear gas mask";
    public static int GAS_ID=R.mipmap.pollution;
    public static final int MAX_GAS=35;




}
