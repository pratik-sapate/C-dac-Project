package com.example.sunbeam.smart_city;

public class Urls {

    public static String TEMPERATURE="https://io.adafruit.com/api/v2/Suraj_Pratik/dashboards/smart-city/blocks/?X-AIO-Key=19452a4cd5ab4d3bbd7033931866cdd2";
 //   public static String LDR="https://io.adafruit.com/api/v2/pratik_sapate/dashboards/smart-city-management/blocks/?X-AIO-Key=4b0df10f7ba84c078bfec02e3ee803e4";
//    public static String GAS="https://io.adafruit.com/api/v2/pratik_sapate/dashboards/smart-city-management/blocks/?X-AIO-Key=4b0df10f7ba84c078bfec02e3ee803e4";

}