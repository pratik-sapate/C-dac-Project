package com.example.sunbeam.smart_city;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.provider.SyncStateContract;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.annotation.ElementType;

public class DisplayActivity extends AppCompatActivity {

    private final Handler handler = new Handler();
    TextView textTemperature,textGas,textLdr;
    CustomGauge gasgauge;
    int temperature_value,gas_value,ldr_value;
    Thermometer thermometer;
    String  []temp=new String[6];
    int tempNotiId=1,gasNotiValue=2,ldrNotiValue=3;
    int values[]={0,0,0,0,0,0};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        textTemperature=findViewById(R.id.textTemperature);
        textGas=findViewById(R.id.textGas);
        textLdr=findViewById(R.id.textLdr);
        thermometer=findViewById(R.id.thermaid);
        gasgauge=findViewById(R.id.gaugeGas);

        //buttonRefresh=findViewById(R.id.buttonRefresh);
//        getdata(Urls.TEMPERATURE);

        doTheAutoRefresh();
    }
    private void doTheAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //code for refresh logic
                getdata(Urls.TEMPERATURE);
                if(temperature_value<Constant_weather.MIN_TEMPERATURE){
                    displayNotification(Constant_weather.WINTER_TITLE,Constant_weather.WINTER_NEWS,Constant_weather.WINTER_ID,tempNotiId);
                }
                else if(temperature_value>Constant_weather.MAX_TEMPERATURE){
                    displayNotification(Constant_weather.SUNNY_TITLE,Constant_weather.SUNNY_NEWS,Constant_weather.SUNNY_ID,tempNotiId);
                }

                if(gas_value>Constant_weather.MAX_GAS)
                {
                    displayNotification(Constant_weather.GAS_TITLE,Constant_weather.GAS_TEXT,Constant_weather.GAS_ID,gasNotiValue);
                }

                thermometer.setCurrentTemp(temperature_value);
                gasgauge.setValue(gas_value);
                doTheAutoRefresh();
            }
        }, 1000);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("About Us");
        menu.add("Exit");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("About Us")) {
            Intent intent = new Intent(this, AboutUs.class);
            startActivity(intent);
        }
        else if(item.getTitle().equals("Exit")){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void getdata(String url)
    {
        System.out.println("Hello");

        Ion.getDefault(this).getCache().clear();
        Ion.with(DisplayActivity.this)
            .load("GET", url)
            .asJsonArray()
            .setCallback(new FutureCallback<JsonArray>() {
                @Override
                public void onCompleted(Exception e, JsonArray result) {
//                    temp=new String[result.size()];
                    for(int i=0;i<6;i++) {
                        System.out.println("-----"+i+"-------");
                        JsonObject object = result.get(i).getAsJsonObject();
                        JsonArray block_feeds = object.getAsJsonArray("block_feeds");
                        JsonObject obj = block_feeds.get(0).getAsJsonObject();
                        JsonObject feed = obj.getAsJsonObject("feed");
                        System.out.println(feed);
                        JsonElement last = feed.get("last_value");

                        JsonElement key = feed.get("key");
                        System.out.println("key "+key);

                        temp[i] = last.getAsString();
                        System.out.println("value of sensor "+temp[i]);

                        for(int j=0;j<temp[i].length();j++)
                        {                     //value of json is coming in string so we need to convert into integer
                            if(Character.isDigit(temp[i].charAt(j)))
                            {
                                values[i]=values[i]*10+Character.getNumericValue(temp[i].charAt(j));
                                System.out.println("values "+values[i]);
                            }
                        }
                    }
//                    temperature_value=values[0];
//                    gas_value=((values[1]*100)/256);
//                    ldr_value=((values[2]*100)/256);
                    temperature_value=values[3];
                    ldr_value=values[0];
                    gas_value=values[2];

                    textTemperature.setText("Temperature = "+String.valueOf(temperature_value));
                    textGas.setText("gas value = "+String.valueOf(gas_value));
                    textLdr.setText("LDR value"+String.valueOf(ldr_value));



                    values[0]=values[1]=values[2]=values[3]=values[4]=values[5]=0;


                }
            });
    }
    protected void displayNotification(String title,String text,int id,int notiid) {
//Get an instance of NotificationManager//

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(id)
                        .setContentTitle(title)
                        .setContentText(text);
                NotificationManager mNotificationManager =(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.notify(notiid, mBuilder.build());
    }
}

