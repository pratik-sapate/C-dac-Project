package com.example.sunbeam.smart_city;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        addElements();
    }
    public void addElements() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        //About Us
        TextView aboutus = new TextView(this);
        aboutus.setText("----created by");
        aboutus.setTextColor(Color.GREEN);
        layout.addView(aboutus);

        TextView pratik = new TextView(this);
        pratik.setText("Pratik Sapate");
        layout.addView(pratik);

        TextView suraj = new TextView(this);
        suraj.setText("Suraj Ombale\n");
        layout.addView(suraj);

        TextView SpecialThanks = new TextView(this);
        SpecialThanks.setText("----Special Thanks to");
        SpecialThanks.setTextColor(Color.GREEN);
        layout.addView(SpecialThanks);

        TextView Nilesh = new TextView(this);
        Nilesh.setText("Prof. Nilesh Ghule");
        layout.addView(Nilesh);

        TextView Amit = new TextView(this);
        Amit.setText("Prof. Amit Kulkarni");
        layout.addView(Amit);

        TextView Devendra = new TextView(this);
        Devendra.setText("Mr. Devendra Dhande");
        layout.addView(Devendra);

        TextView Ganesh = new TextView(this);
        Ganesh.setText("Mr. Ganesh Gundre");
        layout.addView(Ganesh);

        TextView Supriya = new TextView(this);
        Supriya.setText("Mrs. Supriya Patil");
        layout.addView(Supriya);

        TextView Rohan = new TextView(this);
        Rohan.setText("Mr. Rohan");
        layout.addView(Rohan);


        LinearLayout layoutButtons = new LinearLayout(this);
        layoutButtons.setOrientation(LinearLayout.HORIZONTAL);

        // button to save the contents
        Button buttonExit = new Button(this);
        buttonExit.setText("Exit");
        buttonExit.setAllCaps(false);
        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        layoutButtons.addView(buttonExit);
        layout.addView(layoutButtons);
        setContentView(layout);
    }
}
