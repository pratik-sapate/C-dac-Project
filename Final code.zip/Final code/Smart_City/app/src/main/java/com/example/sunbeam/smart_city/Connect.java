package com.example.sunbeam.smart_city;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;


public class Connect extends AppCompatActivity {
    Button imageButtonConnect;
    ProgressBar progessBarWait;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);
        imageButtonConnect=findViewById(R.id.imageButtonConnect);
        progessBarWait=findViewById(R.id.progressBarWait);
    }

    public void onclickConnect(View view) {
        ConnectivityManager check=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        if(check!=null)
        {
            NetworkInfo[] info = check.getAllNetworkInfo();
            for (int i = 0; i <info.length; i++)
                if (info[i].getState() == NetworkInfo.State.CONNECTED)
                {
                    Intent intent=new Intent(Connect.this,DisplayActivity.class);
                    startActivity(intent);
                    finish();
                }
                else if(info[i].getState()==NetworkInfo.State.CONNECTING)
                {
                    progessBarWait.setVisibility(View.VISIBLE);
                }
                else if(info[i].getState()==NetworkInfo.State.DISCONNECTED)
                {
                    Toast.makeText(this, "internet connection required",
                            Toast.LENGTH_SHORT).show();
                }

        }
        else
        {
            Toast.makeText(this, "internet connection required",
                    Toast.LENGTH_SHORT).show();
        }



    }


}
